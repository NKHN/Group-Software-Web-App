<?php
	ini_set('display_errors', 1);
	require('include/conn.inc.php');
 ?>




<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<link rel="shortcut icon" type="image/x-icon" href="Images/icon.ico">
	<title>iPhone</title>
	<script src="//ajax.googleapis.com/ajax/libs/jquery/1.8.2/jquery.min.js"></script>
<!-- bxSlider Javascript file -->
<script src="/js/jquery.bxslider.min.js"></script>
<!-- bxSlider CSS file -->
<link href="/lib/jquery.bxslider.css" rel="stylesheet" />
<link href="css/bootstrap.min.css" rel="css/custom.css">
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<meta charset="utf-8">
	<script src="Javascript/Javascript.js" type="text/javascript"></script>
</head>
<body>
	<header class="header">
		<img id="logo" src="Images/3squaredlogo.jpg" alt="3Squared Logo">
		<nav class="navbar navbar-default">
		<div class="container" id="nav-container">
			<div class="navbar-header">
				<button type="button"
				class="navbar-toggle collapsed"
				data-toggle="collapse"
				data-target="#collapsemenu">
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
				</button>
			</div>
			<div class="collapse navbar-collapse" id="collapsemenu">
				<ul class="navbar-nav nav">
					<li><a class="headerButton"  href="profile.php">PROFILE</a></li>
					<li><a class="headerButton" href="editPage.php">EDIT ASSETS</a></li>
					<li><a class="headerButton" href="searchPage">SEARCH</a></li>
					<li><a class="headerButton" id="currentPage" href="categories.php">CATEGORIES</a></li>
					<li><a class="headerButton" href="login.php">LOGOUT</a></li>
				</ul>
			</div>
		</div>
	</nav>
		<div class="imgClear"></div>
	</header>
</head>


</div>

<div class="container-fluid">
	<h1 class="container">ASUS Laptops</h1> <br>
		<h1><?php echo("$name")?></h1>
		<table>
			<thead class="thead">
				<th>Asset Number</th>
				<th>Name</th>
				<th>Owning Employee</th>
				<th>Model</th>
			</thead>

			<tbody>
				<?php
			 	$query = "SELECT * FROM assetsTable WHERE Category = 'Laptop ASUS'";
				$stmt = $pdo->query($query);

			 	while($row = $stmt -> fetchObject())
				{
			// echo " <li> - {$row->assetTag} - {$row->name} </li>";
					echo "<tr>";
					echo "<td>{$row->assetTag} </td>";
					echo "<td>{$row->name} </td>";
					echo "<td>{$row->employeeName} </td>";
					echo "<td>{$row->model} </td>";
					echo "</tr>";
			 	}
			  	?>


			</tbody>

		</table>
			<div class="textbox">
					<a href="categories.php" class="backbtn">Back</a>
			</div>


</div>

<p></p>
<div id="footer">
      <div class="footerText">
         &copy 2016 3Squared Asset Management
        <a href="profile.html">Profile</a>
        <a href="searchPage.html">Search</a>
        <a href="categories.html">Categories</a>
        <a href="login.html">Logout</a>
      </div>
</div>
</div>
</div>
</body>
</html>
