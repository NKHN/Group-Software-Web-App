<?php
session_start();
ini_set('display_errors', 1);
require('include/conn.inc.php');
$sql = "SELECT name FROM assetsTable where assetTag='3SQA0001'";
$stmt = $pdo->query($sql);
$row = $stmt->fetchObject();
?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<link rel="shortcut icon" type="image/x-icon" href="Images/icon.ico">
	<title>Asset Categories</title>

</head>
<body>
	<header class="header">
		<img id="logo" src="Images/3squaredlogo.jpg" alt="3Squared Logo">
		<nav class="navbar navbar-default">
		<div class="container" id="nav-container">
			<div class="navbar-header">
				<button type="button"
				class="navbar-toggle collapsed"
				data-toggle="collapse"
				data-target="#collapsemenu">
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
				</button>
			</div>
			<div class="collapse navbar-collapse" id="collapsemenu">
				<ul class="navbar-nav nav">
					<li><a class="headerButton"  href="profile.php">PROFILE</a></li>
					<li><a class="headerButton" href="editPage.php">EDIT ASSETS</a></li>
					<li><a class="headerButton" href="searchPage">SEARCH</a></li>
					<li><a class="headerButton" id="currentPage" href="categories.php">CATEGORIES</a></li>
					<li><a class="headerButton" href="login.php">LOGOUT</a></li>
				</ul>
			</div>
		</div>
	</nav>
		<div class="imgClear"></div>
	</header>

	<div class="container-fluid">
		<div class="row">
			<div class="col-xs-12">
				<h2><style type="text/css">text-decoration: underline;</style>Asset Categories</h2>
				<p>Click on the button to open the dropdown menu.</p>
			</div>
		</div>

		<div class="row">
	        <div class="clearFix visible-md-block visible-lg-block"></div>

			<section class="col-md-3 col-sm-6">
				<div class="dropdown">
					<button type="button" data-toggle="dropdown" class="btn btn-info dropdown-toggle">Phones <span class="caret"></span></button>
                	<ul class="dropdown-menu">
                		<li><a href="iphone.php">iPhone</a></li><br>
                    	<li><a href="samsung.php">Samsung</a></li><br>
                    	<li><a href="nokia.php">Nokia</a></li>
                	</ul>
            	</div>
            </section>

            <section class="col-md-3 col-sm-6">
            	<div class="dropdown">
            		<button type="button" data-toggle="dropdown" class="btn btn-info dropdown-toggle">Physical Resources <span class="caret"></span></button>
            		<ul class="dropdown-menu">
            			<li><a href="#Chairs">Chairs</a></li><br>
                    	<li><a href="#Tablets">Tables</a></li><br>
                    	<li><a href="#Printers">Printers</a></li>
                    </ul>
            	</div>`
            </section>

            <section class="col-md-3 col-sm-6">
            	<div class="dropdown">
                	<button type="button" data-toggle="dropdown" class="btn btn-info dropdown-toggle">Laptops <span class="caret"></span></button>
                	<ul class="dropdown-menu">
                		<li><a href="#Mac">Mac</a></li><br>
                    	<li><a href="#HP">HP</a></li><br>
                    	<li><a href="#ASUS">ASUS</a></li>
                	</ul>
                </div>
            </section>

            <section class="col-md-3 col-sm-6">
            	<div class="dropdown">
                	<button type="button" data-toggle="dropdown" class="btn btn-info dropdown-toggle">Tablets <span class="caret"></span></button>
                	<ul class="dropdown-menu">
                		<li><a href="#Ipad">Ipad</a></li><br>
                    	<li><a href="#Samsung">Samsung</a></li><br>
                    	<li><a href="amazon.php">Amazon</a></li>
                	</ul>
                </div>
            </section>
        </div>
	</div>

	<footer class="footer">
		&copy 2017 3Squared Asset Management<br>
		<a href="profile.php">Profile</a>
		<a href="editPage.php">Edit Assets</a>
		<a href="searchPage.php">Search</a>
		<a href="categories.php">Categories</a>
		<a href="login.php">Logout</a>
	</footer>

	<script type="text/javascript" src="js/jquery-3.1.1.min.js"></script>
	<script type="text/javascript" src="js/bootstrap.min.js"></script>
</body>
</html>
