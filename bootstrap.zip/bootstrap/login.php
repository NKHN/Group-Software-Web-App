<?php
session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="css/login.css">

	<link rel="shortcut icon" type="image/x-icon" href="Images/icon.ico">
	<title>Login</title>
</head>
<body>

	<div class="container">
		<header class="header">
			<img id="logo" src="Images/3squaredlogo.jpg" alt="3Squared Logo">
			<h1>Login</h1>
			<h4 id="asset_manage">ASSET MANAGEMENT</h4>
			<div class="passError"> <?php echo $passError ?> </div>
		</header>
	</div>

	<div class="container">
		<div class="row">
			<div class="col-xs-12">
				<form class="form" action="loginLogic.php" method="post">
					<fieldset class="fieldset">
						<label class="label" for="user">Username</label><br>
						<input class="input" type="text" name="user" size="35" placeholder="3SQA0001"><br>
						<label class="label" for="pass">Password</label><br>
						<input class="input" type="password" name="pass" size="35" placeholder="********"><br>
						<input class="button" type="submit" name="submit" value="Log In"></input>
					</fieldset>
				</form>
			</div>
		</div>
	</div>

	<footer class="footer">
		&copy; 2017 3Squared Asset Management <br>
		<a href="profile.php">PROFILE</a>
		<a herf="editPage.php">EDIT ASSETS</a>
		<a href="searchPage.php">SEARCH</a>
		<a href="categories.php">CATEGORIES</a>
	</footer>
	<script type="text/javascript" src="js/jquery-3.1.1.min.js"></script>
	<script type="text/javascript" src="js/bootstrap.min.js"></script>
</body>
</html>