<?php
session_start();
ini_set("display_errors", 1);
require("include/conn.inc.php");
$username = $_POST['user'];
$password = $_POST['pass'];

if($username == "" || $password == "")
{
	$passError = '';
	$passError = "Your username or password is incorrect";
	header("Location: login.php");
}

if ($username && $password)
{
	$sql = "SELECT * FROM loginTable WHERE username= :username AND password = :password";
	$stmt = $pdo->prepare($sql);
	$stmt->bindParam(':username', $username, PDO::PARAM_STR);
	$stmt->bindParam(':password', $password, PDO::PARAM_STR);
    $stmt->execute();
	$numrows = $stmt->rowCount();

	if($numrows===1)
	{
		$_SESSION['login'] = $username;
		header("Location: profile.php");
	}
	else
	{
		$passError = '';
		$passError= "Your username or password is incorrect";
		header("Location: login.php");
	}
}
?>