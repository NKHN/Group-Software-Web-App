<?php
session_start();
ini_set('display_errors', 1);
require('include/conn.inc.php');

$name = $_SESSON['login'];
?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<link rel="shortcut icon" type="image/x-icon" href="Images/icon.ico">
	<title>Profile Page</title>
</head>
<body>
	<header class="header">
		<img id="logo" src="Images/3squaredlogo.jpg" alt="3Squared Logo">
		<nav class="navbar navbar-default">
		<div class="container" id="nav-container">
			<div class="navbar-header">
				<button type="button"
				class="navbar-toggle collapsed"
				data-toggle="collapse"
				data-target="#collapsemenu">
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
				</button>
			</div>
			<div class="collapse navbar-collapse" id="collapsemenu">
				<ul class="navbar-nav nav">
					<li><a class="headerButton" id="currentPage" href="profile.php">PROFILE</a></li>
					<li><a class="headerButton" href="edit123.php">EDIT ASSETS</a></li>
					<li><a class="headerButton" href="searchPage">SEARCH</a></li>
					<li><a class="headerButton" href="categories.php">CATEGORIES</a></li>
					<li><a class="headerButton" href="login.php">LOGOUT</a></li>
				</ul>
			</div>
		</div>
	</nav>
		<div class="imgClear"></div>
	</header>
	<div class="container-fluid">
		<div class="textBox">
			<h1><?php echo("$name")?></h1>
			<table>
				<thead class="thead">
					<th>Asset Tag</th>
					<th>Name</th>
					<th>Manufacturer</th>
					<th>Serial Number</th>
				</thead>

				<tbody>
					<?php
 						$query = "SELECT * FROM assetsTable WHERE employeeName = 'Nick Hanson'";
						$stmt = $pdo->query($query);
 						while($row = $stmt -> fetchObject())
						{
						// echo " <li> - {$row->assetTag} - {$row->name} </li>";
							echo "<tr>";
							echo "<td>{$row->assetTag} </td>";
							echo "<td>{$row->name} </td>";
							echo "<td>{$row->manufacturer} </td>";
							echo "<td>{$row->model} </td>";
							echo "</tr>";
 						}
 					 ?>
				</tbody>
			</table>
		</div>
	</div>

	<footer class="footer">
		&copy 2017 3Squared Asset Management<br>
		<a href="profile.php">Profile</a>
		<a href="editPage.php">Edit Assets</a>
		<a href="searchPage.php">Search</a>
		<a href="categories.php">Categories</a>
		<a href="login.php">Logout</a>
	</footer>
</body>
</html>
