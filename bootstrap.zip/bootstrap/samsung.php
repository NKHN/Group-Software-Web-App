<?php 
	ini_set('display_errors', 1);
	require('include/conn.inc.php');
 ?>




<!DOCTYPE html>
<html>
<head>
	<title>Samsung</title>
	<script src="//ajax.googleapis.com/ajax/libs/jquery/1.8.2/jquery.min.js"></script>
<!-- bxSlider Javascript file -->
<script src="/js/jquery.bxslider.min.js"></script>
<!-- bxSlider CSS file -->
<link href="/lib/jquery.bxslider.css" rel="stylesheet" />
<link href="css/bootstrap.min.css" rel="css/custom.css">
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<meta charset="utf-8"> 
	<script src="Javascript/Javascript.js" type="text/javascript"></script>
</head>
<body>
		<header> 
			<div id="headerLogo">
				<img src="Images/3Squaredlogo.jpg" width="250px" height="80px">
			</div>
			<div id="headerLinks">
				<a class="headerButton"  href="profile.php">PROFILE</a>
				<a class="headerButton"  href="temp - searchPage.php">SEARCH</a>
				<a class="headerButton" id="currentPage" href="categories1.php">CATEGORIES</a>
				<a class="headerButton" href="edit123.php">EDIT</a>
				<a class="headerButton" href="login.php">LOGOUT</a>
			</div>
				<div class="imgClear"></div>
		</header>	
</head>
<body>

<div class="background">
<div class="textbox">
	 <a href="categories1.php" class="backbtn">Back</a>	
</div>
<p></p>
<h1 class="container">Samsung Mobile Devices</h1>
<div class="background">
<div class="container">
	<div class="txtbox">

	<table align="center">
	<tr>
		<th>Asset Number</th> 
		<th>Name</th>
		<th>Owning Employee</th>
		<th>Model</th>
	</tr>
		
	<?php 
 	$query = "SELECT * FROM assetsTable WHERE Category = 'Phones Samsung'";
	$stmt = $pdo->query($query);

 	while($row = $stmt -> fetchObject())
	{
// echo " <li> - {$row->assetTag} - {$row->name} </li>";
		echo "<tr>";
		echo "<td>{$row->assetTag} </td>";
		echo "<td>{$row->name} </td>";
		echo "<td>{$row->employeeName} </td>";
		echo "<td>{$row->model} </td>";
		echo "</tr>";
 	}

  	?>
	</div>
	</table>
	
</div>
<p></p>
<div id="footer">
      <div class="footerText">
         &copy 2016 3Squared Asset Management
        <a href="profile.html">Profile</a>
        <a href="searchPage.html">Search</a>
        <a href="categories.html">Categories</a>
        <a href="login.html">Logout</a>
      </div>
</div>
</div>
</div>
</body>
</html>